const express = require('express');
const app = express();
app.listen(3000, function() {
  console.log('listening on 3000')
})

app.get('/', function(req, res) {
  res.send('Hello World')
})

var MongoClient = require('mongodb').MongoClient;

MongoClient.connect('mongodb://localhost:27017/tache', function(err, db) {
  if (err) {
    throw err;
  }
  db.collection('tache').find().toArray(function(err, result) {
    if (err) {
      throw err;
    }
    console.log(result);
  });
});
